package com.lms.android.lms;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognitionClient;
import com.amazonaws.services.rekognition.model.DetectTextRequest;
import com.amazonaws.services.rekognition.model.DetectTextResult;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.TextDetection;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.util.IOUtils;
import com.lms.android.lms.aws.S3Uploader;
import com.lms.android.lms.aws.S3Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int SELECT_PICTURE = 1;

    private Button detect;
    private Button upload;

    private ListView detectedTextListView;
    private ArrayAdapter<String> arrayAdapter;
    private File resultFile;
    S3Uploader s3uploaderObj;
    String urlFromS3 = null;
    ProgressDialog progressDialog;
    private String TAG = MainActivity.class.getCanonicalName();
    TextView tvStatus;
    ImageView ivSelectedImage;
    String imagePATH;
    File savefile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        detect = (Button) findViewById(R.id.detect_button);
        upload = (Button) findViewById(R.id.upload_button);
        detectedTextListView = (ListView) findViewById(R.id.detectedTextListView);
        ivSelectedImage = (ImageView)findViewById(R.id.image_selected);
        detect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);

            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                S3IntentTask s3 =new S3IntentTask();
                s3.execute(imagePATH);
                Toast.makeText(getApplicationContext(), "�뾽濡쒕뱶 以�", Toast.LENGTH_LONG).show();
            }
        });
        detectedTextListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int check_position = detectedTextListView.getCheckedItemPosition();   //由ъ뒪�듃酉곗쓽 �룷吏��뀡�쓣 媛��졇�샂.
                String strstr = (String)adapterView.getAdapter().getItem(i);  //由ъ뒪�듃酉곗쓽 �룷吏��뀡 �궡�슜�쓣 媛��졇�샂.
                makeFile(strstr);
                Toast.makeText(getApplicationContext(), "寃�異� �뙆�씪 �깮�꽦�셿猷�", Toast.LENGTH_LONG).show();

            }

        });


    }



    @Override
    protected void onStart() {
        super.onStart();
        if (Build.VERSION.SDK_INT >= 23) {
            int check1 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
            int check2 = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (check1 != PackageManager.PERMISSION_GRANTED && check2 != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, 101);
            }
        }
    }

    public String getPath(Uri uri) { //�뙆�씪�쓣 �떎�젣 二쇱냼 �뼸湲�
        String filePath = "";
        String wholeID = DocumentsContract.getDocumentId(uri);

        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];

        String[] column = {MediaStore.Images.Media.DATA};

        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";

        Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                column, sel, new String[]{id}, null);

        int columnIndex = cursor.getColumnIndex(column[0]);

        if (cursor.moveToFirst()) {
            filePath = cursor.getString(columnIndex);
        }
        cursor.close();
        return filePath;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                Uri selectedImageUri = data.getData();
                String selectedImagePath = getPath(selectedImageUri);
                if (selectedImagePath != null) {
                    detectText(selectedImagePath);
                    InputStream imageStream = null;
                    try {
                        imageStream = getContentResolver().openInputStream(selectedImageUri);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    ivSelectedImage.setImageBitmap(BitmapFactory.decodeStream(imageStream));
                    //uploadImageTos3(selectedImageUri);
                    imagePATH =selectedImagePath;
                }

            }
        }
    }

    //�뀓�뒪�듃 寃�異�
    public void detectText(String selectedImagePath) {
        File file = new File(selectedImagePath);
        try {
            InputStream in = new FileInputStream(file.getAbsolutePath());
            ByteBuffer imageBytes = ByteBuffer.wrap(IOUtils.toByteArray(in));

            Image image = new Image();
            image.withBytes(imageBytes);

            DetectTextTask task = new DetectTextTask();
            task.execute(image);
            Toast.makeText(this, "寃�異쒕맆 �뙆�씪�깮�꽦: "+file.getName() , Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    //Rekognition �뿰�룞
    private class DetectTextTask extends AsyncTask<Image, Void, List<TextDetection>> {
        @Override
        protected List<TextDetection> doInBackground(Image... params) {

            CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                    getApplicationContext(),
                    "*****************", // �옄寃� 利앸챸 �� ID,
                    Regions.AP_NORTHEAST_2
            );

            AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient(credentialsProvider);

            DetectTextRequest request = new DetectTextRequest().withImage(params[0]);

            DetectTextResult result = rekognitionClient.detectText(request);

            return result.getTextDetections();
        }

        //寃곌낵媛� string �깮�꽦
        @Override
        protected void onPostExecute(List<TextDetection> textDetections) {
            super.onPostExecute(textDetections);
            List<String> detectedTextList = new ArrayList<>();
            String resultstr = "";
            for (TextDetection text : textDetections) {
                resultstr += text.getDetectedText() + "\n";
                //resultstr += "Height : " + text.getGeometry().getBoundingBox().getHeight() + "\n";
                //resultstr += "Width : " + text.getGeometry().getBoundingBox().getWidth() + "\n";
                //resultstr += "Top : " + text.getGeometry().getBoundingBox().getTop() + "\n";
                //resultstr += "Left : " + text.getGeometry().getBoundingBox().getLeft() + "\n";
                detectedTextList.add(resultstr);
                //makeFile(resultstr);
            }
            arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, detectedTextList);
            detectedTextListView.setAdapter(arrayAdapter);

        }

    }

    private void makeFile(String resultstr){
        String dirPath = getFilesDir().getAbsolutePath();
        File file = new File(dirPath);
        // �씪移섑븯�뒗 �뤃�뜑媛� �뾾�쑝硫� �깮�꽦
        if( !file.exists() ) {
            file.mkdirs();
            Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
        }
        // txt �뙆�씪 �깮�꽦
        String testStr = resultstr;
        savefile = new File(dirPath+"/test.txt");
        try{
            FileOutputStream fos = new FileOutputStream(savefile);
            fos.write(testStr.getBytes());
            fos.close();
        } catch(IOException e){}
        // �뙆�씪�씠 1媛� �씠�긽�씠硫� �뙆�씪 �씠由� 異쒕젰
        if ( file.listFiles().length > 0 )
        for ( File f : file.listFiles() ) {
            String str = f.getName();
            Log.v(null,"fileName : "+str);
        }
    }

    private void uploadImageTos3(Uri imageUri) {
        final String path = getPath(imageUri);
        if (path != null) {
            showLoading("Uploading details !!");
            s3uploaderObj.initUpload(path);
            s3uploaderObj.setOns3UploadDone(new S3Uploader.S3UploadInterface() {
                @Override
                public void onUploadSuccess(String response) {
                    if (response.equalsIgnoreCase("Success")) {
                        hideLoading();
                        urlFromS3 = S3Utils.generates3ShareUrl(getApplicationContext(), path);
                        if(!TextUtils.isEmpty(urlFromS3)) {
                            tvStatus.setText("Uploaded : "+urlFromS3);
                        }
                    }
                }

                @Override
                public void onUploadError(String response) {
                    hideLoading();
                    tvStatus.setText("Error : "+response);
                    Log.e(TAG, "Error Uploading");

                }
            });
        }
    }


    private void showLoading(String message) {
        if (progressDialog != null && !progressDialog.isShowing()) {
            progressDialog.setMessage(message);
            progressDialog.setCancelable(false);
            progressDialog.show();
        }
    }

    private void hideLoading() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    //s3 �뿰�룞
    private class S3IntentTask extends AsyncTask<String, Void, Void> {
        //s3 congnition �씤利�
        @Override
        protected Void doInBackground(String... params) {
            CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                    getApplicationContext(),
                    "******************************", // �옄寃� 利앸챸 �� ID,
                    Regions.AP_NORTHEAST_2
            );
            //踰꾩폆�뿉 �뾽濡쒕뱶
            AmazonS3Client s3Client = new AmazonS3Client(credentialsProvider);
            File fileToUpload = new File(params[0]);
            PutObjectRequest putRequest = new PutObjectRequest("proj5022", savefile.getName(),
                    savefile);
            PutObjectResult putResponse = s3Client.putObject(putRequest);

            GetObjectRequest getRequest = new GetObjectRequest("proj5022", savefile.getName());
            com.amazonaws.services.s3.model.S3Object getResponse = s3Client.getObject(getRequest);
            InputStream myObjectBytes = getResponse.getObjectContent();

            try {
                myObjectBytes.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

    }

}
