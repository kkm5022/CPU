package com.lms.android.lms.aws;

import com.amazonaws.regions.Regions;

public class AWSKeys {
    protected static final String COGNITO_POOL_ID = "*****************************";
    protected static final Regions MY_REGION = Regions.AP_NORTHEAST_2; // WHAT EVER REGION IT MAY BE, PLEASE CHOOSE EXACT
    public static final String BUCKET_NAME = "proj5022";

}
