# Text Detection AWS Rekognition

An Android app to recognize text in an image using AWS Rekognition service.

## AWS Rekogntion Setup
- Create an AWS account.
- Create an Cognito Identity Pool
- Copy/Paste the Identity Pool ID in MainActivity.java

## Clone Repository
```
$ git clone https://github.com/amanraj209/Text-detection-AWSRekognition.git
```